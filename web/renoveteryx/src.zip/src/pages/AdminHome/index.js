import React from "react";

function AdminHome() {
  return (
    <div>
      <h1>this is admin home t</h1>
    </div>
  );
}

export default AdminHome;
