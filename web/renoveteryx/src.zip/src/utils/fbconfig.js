import { initializeApp } from "firebase/app";
const firebaseConfig = {
  apiKey: "AIzaSyCi_O1Lief7hVM3gWpOjP1kruwYJlRu6wk",
  authDomain: "csse-53.firebaseapp.com",
  projectId: "csse-53",
  storageBucket: "csse-53.appspot.com",
  messagingSenderId: "627858556749",
  appId: "1:627858556749:web:e11819c2e6448cdc8d1904",
  measurementId: "G-E9FZ7FVR51",
};
const app = initializeApp(firebaseConfig);
export { app };
